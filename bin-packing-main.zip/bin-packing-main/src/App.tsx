import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import {
  Box,
  Button,
  Checkbox,
  IconButton,
  Step,
  StepLabel,
  Stepper,
  Tab,
  Tabs,
  TextField,
  Typography,
} from '@mui/material';
import React, { useState } from 'react';

interface TableSize {
  width: number;
  height: number;
}
interface Quantities {
  p: number;
  m: number;
  g: number;
}

interface TableSizeStepProps {
  tableSize: TableSize;
  setTableSize: React.Dispatch<React.SetStateAction<TableSize>>;
  onNext: () => void;
}
const TableSizeStep: React.FC<TableSizeStepProps> = ({ tableSize, setTableSize, onNext }) => {
  const handleChange = (field: keyof TableSize) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setTableSize({ ...tableSize, [field]: Number(e.target.value) });
  };
  return (
    <Box>
      <Box display="flex" gap={2}>
        <Box flex={1}>
          <TextField label="Width (cm)" type="number" fullWidth value={tableSize.width} onChange={handleChange('width')} />
        </Box>
        <Box flex={1}>
          <TextField label="Height (cm)" type="number" fullWidth value={tableSize.height} onChange={handleChange('height')} />
        </Box>
      </Box>
      <Box mt={2}>
        <Button variant="contained" onClick={onNext}>Next</Button>
      </Box>
    </Box>
  );
};

interface QuantityStepProps {
  quantities: Quantities;
  setQuantities: React.Dispatch<React.SetStateAction<Quantities>>;
  onNext: () => void;
  onBack: () => void;
}
const QuantityStep: React.FC<QuantityStepProps> = ({ quantities, setQuantities, onNext, onBack }) => {
  const adjust = (key: keyof Quantities, delta: number) => () => {
    setQuantities({ ...quantities, [key]: Math.max(0, quantities[key] + delta) });
  };
  return (
    <Box>
      {(['p', 'm', 'g'] as Array<keyof Quantities>).map((size) => (
        <Box key={size} display="flex" alignItems="center" mb={1}>
          <Typography variant="body1" mr={2} textTransform="uppercase">{size}</Typography>
          <IconButton onClick={adjust(size, -1)}><RemoveIcon /></IconButton>
          <Typography mx={1}>{quantities[size]}</Typography>
          <IconButton onClick={adjust(size, 1)}><AddIcon /></IconButton>
        </Box>
      ))}
      <Box mt={2}>
        <Button onClick={onBack}>Back</Button>
        <Button variant="contained" onClick={onNext} sx={{ ml: 1 }}>Next</Button>
      </Box>
    </Box>
  );
};

interface PreviewStepProps {
  quantities: Quantities;
  onBack: () => void;
  onReset: () => void;
}
const PreviewStep: React.FC<PreviewStepProps> = ({ quantities, onBack, onReset }) => {
  const [show, setShow] = useState<Record<keyof Quantities, boolean>>({ p: quantities.p > 0, m: quantities.m > 0, g: quantities.g > 0 });
  const [tab, setTab] = useState(0);
  const toggle = (key: keyof Quantities) => () => setShow({ ...show, [key]: !show[key] });
  const handleTabChange = (_: React.SyntheticEvent, newVal: number) => setTab(newVal);

  return (
    <Box display="flex" gap={2}>
      <Box flex={1}>
        <Typography variant="h6">Preview Sizes</Typography>
        {(Object.keys(quantities) as Array<keyof Quantities>).map((k) => (
          <Box key={k} display="flex" alignItems="center">
            <Checkbox checked={show[k]} onChange={toggle(k)} />
            <Typography textTransform="uppercase">{k}</Typography>
          </Box>
        ))}
        <Box mt={2}>
          <Button onClick={onBack}>Back</Button>
          <Button variant="contained" onClick={onReset} sx={{ ml: 1 }}>Reset</Button>
        </Box>
      </Box>
      <Box flex={2}>
        <Tabs value={tab} onChange={handleTabChange}>
          <Tab label="Tab P" />
          <Tab label="Tab M" />
          <Tab label="Tab G" />
        </Tabs>
        <Box mt={2}><Typography>Tab content goes here.</Typography></Box>
      </Box>
    </Box>
  );
};

const steps = ['Table Size', 'Quantities', 'Preview'];
const App: React.FC = () => {
  const [activeStep, setActiveStep] = useState(0);
  const [tableSize, setTableSize] = useState<TableSize>({ width: 0, height: 0 });
  const [quantities, setQuantities] = useState<Quantities>({ p: 0, m: 0, g: 0 });
  const next = () => setActiveStep((s) => s + 1);
  const back = () => setActiveStep((s) => s - 1);
  const reset = () => { setActiveStep(0); setTableSize({ width: 0, height: 0 }); setQuantities({ p: 0, m: 0, g: 0 }); };

  return (
    <Box p={4}>
      <Stepper activeStep={activeStep} alternativeLabel>
        {steps.map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>
      <Box mt={4}>
        {activeStep === 0 && <TableSizeStep tableSize={tableSize} setTableSize={setTableSize} onNext={next} />}
        {activeStep === 1 && <QuantityStep quantities={quantities} setQuantities={setQuantities} onNext={next} onBack={back} />}
        {activeStep === 2 && <PreviewStep quantities={quantities} onBack={back} onReset={reset} />}
      </Box>
    </Box>
  );
};

export default App;
